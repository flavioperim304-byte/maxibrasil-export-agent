import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

const AGENT_SYSTEM_INSTRUCTION = `
Você é o Agente de Exportação Maxibrasil, especializado em prospecção B2B internacional de produtos capilares profissionais da Maxibrasil.
Fabricante brasileiro com linha completa (exceto coloração). Diferencial: ingredientes premium e customização.

MISSÃO: Encontrar, qualificar e abordar distribuidores e importadores na América Latina, Europa, Oriente Médio, Ásia, África, América Central e América do Norte.

REGRA ABSOLUTA — CONTATOS E WHATSAPP:
1. NUNCA invente e-mails ou números. Use APENAS o que encontrar em fontes oficiais ou redes sociais (Instagram, Facebook, LinkedIn, site).
2. FORMATO DO WHATSAPP: O número DEVE conter o código do país (ex: +55 para Brasil, +34 para Espanha, +52 para México).
3. Se encontrar um número local (ex: 91234-5678), identifique o país e ADICIONE o código internacional correspondente.
4. O campo "whatsapp" deve conter o sinal + seguido de APENAS NÚMEROS (sem parênteses, sem espaços, sem pontos).
5. PRIORIDADE MÁXIMA: Tente encontrar o número de WhatsApp para contato direto. Verifique se o número é mobile.
6. OBRIGATÓRIO: Só retorne leads que tenham AMBOS: email verificado E número de WhatsApp verificado.
7. O campo "country" retornado deve ser SEMPRE retornado em INGLÊS (ex: Brazil, Spain, Mexico, United Arab Emirates).
8. Se o número encontrado for um telefone fixo que não parece ter WhatsApp, tente buscar nas redes sociais da empresa.
9. IMPORTANTE: Para países como México (+52) e Argentina (+54), lembre-se das regras específicas de prefixos mobile.

PERFIL IDEAL DE CLIENTE (ICP):
Leads devem ter TODOS os critérios:
- Distribuidora ou importadora (nunca salão, fabricante ou marketplace)
- Site próprio ativo e profissional
- Portfólio com múltiplas marcas capilares
- Estrutura comercial visível
- Email verificado na fonte oficial
- WhatsApp verificado com código do país

REPROVAR imediatamente se:
- É salão de beleza ou escola de cosmetologia
- É fabricante ou OEM
- É marketplace (Amazon, Mercado Livre)
- Sem site profissional
- Sem email verificável
- Sem WhatsApp mobile verificável

SCORING (0-100):
- 90-100: QUENTE — Distribuidora premium com múltiplas marcas, contatos verificados, região estratégica
- 70-89: MORNO — Boa estrutura mas falta algum critério
- 50-69: FRIO — Potencial limitado ou dados incompletos
- 0-49: DESQUALIFICADO

TEMPLATE WHATSAPP (adapte ao idioma do país):
Para países de língua espanhola:
"Hola [nombre], soy [seu nome] de Maxibrasil, fabricante brasileño de productos capilares profesionales. Tenemos una línea completa con ingredientes premium. ¿Podríamos conversar sobre una posible distribución en [país]?"

Para outros países (inglês):
"Hello [name], I'm [seu nome] from Maxibrasil, a Brazilian professional haircare manufacturer. We offer a complete line with premium ingredients. Could we discuss a potential distribution partnership in [country]?"

FORMATO DE RESPOSTA — retorne APENAS JSON válido, sem texto extra, sem markdown:
{
  "leads": [
    {
      "company": "Nome da Empresa",
      "country": "Country in English",
      "website": "https://...",
      "email": "email@empresa.com ou null",
      "isVerified": true,
      "whatsapp": "+5511999999999 ou null",
      "isWhatsappVerified": true,
      "score": 85,
      "status": "QUENTE",
      "reason": "Explicação detalhada da qualificação",
      "internalLog": "Onde encontrou cada dado",
      "tradeActivity": "Descrição da atividade comercial",
      "productsDistributed": ["marca1", "marca2"],
      "keyContact": "Nome do contato se encontrado"
    }
  ]
}
`;

async function startServer() {
  const app = express();
  app.use(express.json());

  // Data persistence
  const dataDir = path.resolve(__dirname, 'data');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);

  const leadsFile = path.join(dataDir, 'leads.json');
  const sessionsFile = path.join(dataDir, 'sessions.json');

  const readJSON = (file: string) => {
    try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
    catch { return []; }
  };
  const writeJSON = (file: string, data: unknown) =>
    fs.writeFileSync(file, JSON.stringify(data, null, 2));

  // ── API Routes ─────────────────────────────────────────────────────────────

  app.get('/api/leads', (req, res) => {
    res.json(readJSON(leadsFile));
  });

  app.post('/api/leads', (req, res) => {
    const leads = readJSON(leadsFile);
    const newLeads: any[] = req.body.leads || [];
    // Deduplication by website
    const existing = new Set(leads.map((l: any) => l.website?.toLowerCase()));
    const toAdd = newLeads.filter((l: any) => !existing.has(l.website?.toLowerCase()));
    const updated = [...leads, ...toAdd];
    writeJSON(leadsFile, updated);
    res.json({ added: toAdd.length, total: updated.length });
  });

  app.put('/api/leads/:id', (req, res) => {
    const leads = readJSON(leadsFile);
    const idx = leads.findIndex((l: any) => l.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Lead not found' });
    leads[idx] = { ...leads[idx], ...req.body };
    writeJSON(leadsFile, leads);
    res.json(leads[idx]);
  });

  app.delete('/api/leads/:id', (req, res) => {
    const leads = readJSON(leadsFile);
    const updated = leads.filter((l: any) => l.id !== req.params.id);
    writeJSON(leadsFile, updated);
    res.json({ ok: true });
  });

  app.get('/api/sessions', (req, res) => {
    res.json(readJSON(sessionsFile));
  });

  app.post('/api/sessions', (req, res) => {
    const sessions = readJSON(sessionsFile);
    sessions.push(req.body);
    writeJSON(sessionsFile, sessions);
    res.json({ ok: true });
  });

  // ── Gemini Search ──────────────────────────────────────────────────────────
  app.post('/api/search', async (req, res) => {
    const { country, region, isAlibaba, leadCount = 3 } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return res.status(500).json({ error: 'GEMINI_API_KEY not set in Secrets' });

    const ai = new GoogleGenAI({ apiKey });

    const searchMode = isAlibaba
      ? `Busque SOMENTE no Alibaba.com (alibaba.com/trade/search) distribuidores e importadores de produtos capilares profissionais em ${country || region}.`
      : `Busque na web distribuidores e importadores de produtos capilares profissionais em ${country || region}.`;

    const prompt = `${searchMode}
Retorne exatamente ${leadCount} leads que atendam ao ICP definido.
Cada lead DEVE ter email verificado E WhatsApp verificado com código do país.
Retorne APENAS JSON válido sem nenhum texto adicional.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.0-flash',
        config: { systemInstruction: AGENT_SYSTEM_INSTRUCTION },
        contents: [{ role: 'user', parts: [{ text: prompt }] }]
      });

      const text = response.text || '';
      const clean = text.replace(/```json|```/g, '').trim();
      let parsed: any = { leads: [] };
      try { parsed = JSON.parse(clean); } catch { parsed = { leads: [] }; }

      res.json({ leads: parsed.leads || [] });
    } catch (err: any) {
      console.error('Gemini error:', err);
      res.status(500).json({ error: err.message || 'Erro na busca' });
    }
  });

  // ── Frontend ───────────────────────────────────────────────────────────────
  const isProduction = process.env.NODE_ENV === 'production';
  const distPath = path.resolve(__dirname, 'dist');

  if (isProduction && fs.existsSync(distPath)) {
    app.use(express.static(distPath));
    app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ Maxibrasil Export Agent rodando em http://localhost:${PORT}`);
  });
}

startServer();
