import React, { useState, useEffect } from 'react';
import {
  Search, Globe, Mail, CheckCircle2, XCircle, AlertCircle, TrendingUp,
  Building2, ChevronRight, Loader2, ExternalLink, Copy, Check, Filter,
  MessageCircle, Flame, Thermometer, Snowflake, Clock, Calendar,
  UserCheck, UserX, ShoppingBag, Trash2, ChevronDown, BarChart3,
  Users, Activity, Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Lead {
  id: string;
  company: string;
  country: string;
  website: string;
  email: string | null;
  isVerified: boolean;
  whatsapp: string | null;
  isWhatsappVerified: boolean;
  score: number;
  status: 'QUENTE' | 'MORNO' | 'FRIO' | 'DESQUALIFICADO' | 'PENDENTE';
  reason: string;
  internalLog?: string;
  tradeActivity?: string;
  productsDistributed?: string[];
  keyContact?: string;
  contactedAt?: string;
  responseStatus?: 'RESPONDED' | 'NO_RESPONSE';
  respondedAt?: string;
  generatedWhatsappContent?: string;
  generatedEmailContent?: string;
  emailGenerated?: boolean;
  whatsappGenerated?: boolean;
}

interface SearchSession {
  id: string;
  timestamp: string;
  country: string;
  region: string;
  isAlibaba: boolean;
  leadsFound: number;
}

const REGIONS = [
  'América Latina', 'Europa', 'Oriente Médio', 'Ásia',
  'África', 'América Central', 'América do Norte'
];

const STATUS_CONFIG = {
  QUENTE:        { color: '#ef4444', bg: '#450a0a', icon: Flame,       label: 'Quente' },
  MORNO:         { color: '#f97316', bg: '#431407', icon: Thermometer, label: 'Morno' },
  FRIO:          { color: '#3b82f6', bg: '#172554', icon: Snowflake,   label: 'Frio' },
  DESQUALIFICADO:{ color: '#6b7280', bg: '#111827', icon: XCircle,     label: 'Desqualificado' },
  PENDENTE:      { color: '#a855f7', bg: '#3b0764', icon: Clock,       label: 'Pendente' },
};

function generateId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function validateWhatsApp(num: string | null): boolean {
  if (!num) return false;
  const digits = num.replace(/\D/g, '');
  return num.startsWith('+') && digits.length >= 10 && digits.length <= 15;
}

function getWhatsAppLink(num: string, company: string): string {
  const clean = num.replace(/\D/g, '');
  const msg = encodeURIComponent(
    `Hello, I'm reaching out from Maxibrasil, a Brazilian professional haircare manufacturer. We'd love to explore a distribution partnership with ${company}.`
  );
  return `https://wa.me/${clean}?text=${msg}`;
}

export default function App() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [sessions, setSessions] = useState<SearchSession[]>([]);
  const [country, setCountry] = useState('');
  const [region, setRegion] = useState('');
  const [isAlibaba, setIsAlibaba] = useState(false);
  const [leadCount, setLeadCount] = useState(3);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'search' | 'leads' | 'stats'>('search');

  // Load data from server on mount
  useEffect(() => {
    fetch('/api/leads').then(r => r.json()).then(setLeads).catch(() => {});
    fetch('/api/sessions').then(r => r.json()).then(setSessions).catch(() => {});
  }, []);

  async function handleSearch() {
    if (!country.trim() && !region) {
      setError('Digite um país ou selecione uma região.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ country, region, isAlibaba, leadCount }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro na busca');

      const newLeads: Lead[] = (data.leads || []).map((l: any) => ({
        ...l,
        id: generateId(),
        isVerified: !!l.email,
        isWhatsappVerified: validateWhatsApp(l.whatsapp),
        emailGenerated: false,
        whatsappGenerated: false,
      }));

      // Save to server
      const saveRes = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leads: newLeads }),
      });
      const saveData = await saveRes.json();

      // Reload leads from server
      const updated = await fetch('/api/leads').then(r => r.json());
      setLeads(updated);

      // Save session
      const session: SearchSession = {
        id: generateId(),
        timestamp: new Date().toISOString(),
        country,
        region,
        isAlibaba,
        leadsFound: saveData.added || 0,
      };
      await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(session),
      });
      setSessions(prev => [...prev, session]);

      setActiveTab('leads');
    } catch (e: any) {
      setError(e.message || 'Erro desconhecido');
    } finally {
      setLoading(false);
    }
  }

  async function updateLead(id: string, patch: Partial<Lead>) {
    const res = await fetch(`/api/leads/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    });
    const updated = await res.json();
    setLeads(prev => prev.map(l => l.id === id ? updated : l));
  }

  async function deleteLead(id: string) {
    await fetch(`/api/leads/${id}`, { method: 'DELETE' });
    setLeads(prev => prev.filter(l => l.id !== id));
  }

  function exportCSV() {
    const headers = ['Company','Country','Website','Email','WhatsApp','Score','Status','Reason','Key Contact','Contacted','Response'];
    const rows = leads.map(l => [
      l.company, l.country, l.website, l.email || '',
      l.whatsapp || '', l.score, l.status, l.reason,
      l.keyContact || '', l.contactedAt || '', l.responseStatus || ''
    ]);
    const csv = [headers, ...rows].map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = `maxibrasil_leads_${new Date().toISOString().slice(0,10)}.csv`;
    a.click(); URL.revokeObjectURL(url);
  }

  function copyText(text: string, id: string) {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  }

  const filtered = leads.filter(l => filterStatus === 'ALL' || l.status === filterStatus);
  const stats = {
    total: leads.length,
    quente: leads.filter(l => l.status === 'QUENTE').length,
    morno: leads.filter(l => l.status === 'MORNO').length,
    contacted: leads.filter(l => l.contactedAt).length,
    responded: leads.filter(l => l.responseStatus === 'RESPONDED').length,
  };

  return (
    <div style={{ minHeight: '100vh', background: '#0f1117', color: '#e2e8f0', fontFamily: 'Inter, sans-serif' }}>
      {/* Header */}
      <div style={{ background: '#1a1d2e', borderBottom: '1px solid #2d3149', padding: '16px 24px', display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ width: 40, height: 40, borderRadius: 10, background: 'linear-gradient(135deg,#6366f1,#8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Globe size={22} color="#fff" />
        </div>
        <div>
          <h1 style={{ fontSize: 18, fontWeight: 700, color: '#f1f5f9' }}>Maxibrasil Export Agent</h1>
          <p style={{ fontSize: 12, color: '#64748b' }}>Prospecção B2B Internacional</p>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
          {(['search','leads','stats'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              style={{ padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer',
                background: activeTab === tab ? '#6366f1' : '#2d3149',
                color: activeTab === tab ? '#fff' : '#94a3b8', fontWeight: 600, fontSize: 13 }}>
              {tab === 'search' ? 'Buscar' : tab === 'leads' ? `Leads (${leads.length})` : 'Stats'}
            </button>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 1100, margin: '0 auto', padding: 24 }}>

        {/* Search Tab */}
        {activeTab === 'search' && (
          <div style={{ maxWidth: 600, margin: '0 auto' }}>
            <div style={{ background: '#1a1d2e', borderRadius: 16, padding: 32, border: '1px solid #2d3149' }}>
              <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 8, color: '#f1f5f9' }}>Nova Busca</h2>
              <p style={{ color: '#64748b', marginBottom: 24, fontSize: 14 }}>Encontre distribuidores e importadores qualificados</p>

              <div style={{ marginBottom: 16 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>País</label>
                <input value={country} onChange={e => setCountry(e.target.value)}
                  placeholder="Ex: Spain, Mexico, UAE..."
                  style={{ width: '100%', padding: '12px 16px', borderRadius: 10, border: '1px solid #2d3149',
                    background: '#0f1117', color: '#f1f5f9', fontSize: 15, outline: 'none' }} />
              </div>

              <div style={{ marginBottom: 16 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>Ou Região</label>
                <select value={region} onChange={e => setRegion(e.target.value)}
                  style={{ width: '100%', padding: '12px 16px', borderRadius: 10, border: '1px solid #2d3149',
                    background: '#0f1117', color: region ? '#f1f5f9' : '#64748b', fontSize: 15, outline: 'none' }}>
                  <option value="">Selecionar região...</option>
                  {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>

              <div style={{ marginBottom: 24 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>Quantidade de leads</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  {[3, 5, 10].map(n => (
                    <button key={n} onClick={() => setLeadCount(n)}
                      style={{ flex: 1, padding: '10px', borderRadius: 8, border: 'none', cursor: 'pointer',
                        background: leadCount === n ? '#6366f1' : '#2d3149',
                        color: leadCount === n ? '#fff' : '#94a3b8', fontWeight: 600 }}>
                      {n}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24, padding: '12px 16px',
                borderRadius: 10, background: '#0f1117', border: '1px solid #2d3149', cursor: 'pointer' }}
                onClick={() => setIsAlibaba(!isAlibaba)}>
                <div style={{ width: 40, height: 22, borderRadius: 11, background: isAlibaba ? '#6366f1' : '#2d3149',
                  position: 'relative', transition: 'background 0.2s' }}>
                  <div style={{ width: 18, height: 18, borderRadius: 9, background: '#fff', position: 'absolute',
                    top: 2, left: isAlibaba ? 20 : 2, transition: 'left 0.2s' }} />
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: '#f1f5f9' }}>Modo Alibaba</div>
                  <div style={{ fontSize: 12, color: '#64748b' }}>Busca focada no diretório Alibaba.com</div>
                </div>
              </div>

              {error && (
                <div style={{ padding: '12px 16px', borderRadius: 10, background: '#450a0a', border: '1px solid #991b1b',
                  color: '#fca5a5', fontSize: 14, marginBottom: 16 }}>
                  {error}
                </div>
              )}

              <button onClick={handleSearch} disabled={loading}
                style={{ width: '100%', padding: '14px', borderRadius: 12, border: 'none', cursor: loading ? 'not-allowed' : 'pointer',
                  background: loading ? '#2d3149' : 'linear-gradient(135deg,#6366f1,#8b5cf6)',
                  color: '#fff', fontWeight: 700, fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                {loading ? <><Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }} /> Buscando...</> : <><Search size={18} /> Buscar Leads</>}
              </button>
            </div>
          </div>
        )}

        {/* Leads Tab */}
        {activeTab === 'leads' && (
          <div>
            {/* Filter bar */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap', alignItems: 'center' }}>
              {(['ALL', 'QUENTE', 'MORNO', 'FRIO', 'PENDENTE', 'DESQUALIFICADO'] as const).map(s => (
                <button key={s} onClick={() => setFilterStatus(s)}
                  style={{ padding: '8px 14px', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600,
                    background: filterStatus === s ? (s === 'ALL' ? '#6366f1' : STATUS_CONFIG[s]?.bg || '#1a1d2e') : '#1a1d2e',
                    color: filterStatus === s ? (s === 'ALL' ? '#fff' : STATUS_CONFIG[s]?.color || '#fff') : '#64748b' }}>
                  {s === 'ALL' ? `Todos (${leads.length})` : `${STATUS_CONFIG[s].label} (${leads.filter(l => l.status === s).length})`}
                </button>
              ))}
              <button onClick={exportCSV} style={{ marginLeft: 'auto', padding: '8px 16px', borderRadius: 8, border: 'none',
                cursor: 'pointer', background: '#1a1d2e', color: '#6366f1', fontWeight: 600, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                <Download size={14} /> Exportar CSV
              </button>
            </div>

            {filtered.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
                <Users size={48} style={{ margin: '0 auto 16px', opacity: 0.3 }} />
                <p style={{ fontSize: 18, fontWeight: 600 }}>Nenhum lead encontrado</p>
                <p style={{ fontSize: 14, marginTop: 8 }}>Use a aba Buscar para encontrar distribuidores</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {filtered.map(lead => {
                  const cfg = STATUS_CONFIG[lead.status] || STATUS_CONFIG.PENDENTE;
                  const StatusIcon = cfg.icon;
                  const isExpanded = expandedId === lead.id;
                  const hasValidWhatsapp = validateWhatsApp(lead.whatsapp);

                  return (
                    <motion.div key={lead.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                      style={{ background: '#1a1d2e', borderRadius: 14, border: `1px solid ${isExpanded ? '#6366f1' : '#2d3149'}`, overflow: 'hidden' }}>

                      {/* Lead header */}
                      <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 16, cursor: 'pointer' }}
                        onClick={() => setExpandedId(isExpanded ? null : lead.id)}>

                        <div style={{ width: 44, height: 44, borderRadius: 10, background: cfg.bg,
                          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <StatusIcon size={20} color={cfg.color} />
                        </div>

                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                            <span style={{ fontWeight: 700, fontSize: 15, color: '#f1f5f9' }}>{lead.company}</span>
                            <span style={{ fontSize: 12, padding: '2px 8px', borderRadius: 6, background: cfg.bg, color: cfg.color, fontWeight: 600 }}>
                              {cfg.label}
                            </span>
                            {lead.contactedAt && (
                              <span style={{ fontSize: 12, padding: '2px 8px', borderRadius: 6, background: '#172554', color: '#60a5fa', fontWeight: 600 }}>
                                Contactado
                              </span>
                            )}
                          </div>
                          <div style={{ fontSize: 13, color: '#64748b', marginTop: 2 }}>
                            {lead.country} · Score: <span style={{ color: cfg.color, fontWeight: 600 }}>{lead.score}</span>
                          </div>
                        </div>

                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          {lead.email && <Mail size={16} color="#22c55e" />}
                          {hasValidWhatsapp && <MessageCircle size={16} color="#22c55e" />}
                          <ChevronDown size={18} color="#64748b"
                            style={{ transform: isExpanded ? 'rotate(180deg)' : 'rotate(0)', transition: 'transform 0.2s' }} />
                        </div>
                      </div>

                      {/* Expanded content */}
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }} style={{ overflow: 'hidden' }}>
                            <div style={{ padding: '0 20px 20px', borderTop: '1px solid #2d3149' }}>

                              {/* Info grid */}
                              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, margin: '16px 0' }}>
                                {[
                                  { label: 'Website', value: lead.website, link: lead.website },
                                  { label: 'Email', value: lead.email || '—', verified: lead.isVerified },
                                  { label: 'WhatsApp', value: lead.whatsapp || '—', verified: hasValidWhatsapp },
                                  { label: 'Contato', value: lead.keyContact || '—' },
                                ].map(item => (
                                  <div key={item.label} style={{ background: '#0f1117', borderRadius: 10, padding: '12px 14px' }}>
                                    <div style={{ fontSize: 11, color: '#64748b', fontWeight: 600, marginBottom: 4 }}>{item.label}</div>
                                    <div style={{ fontSize: 13, color: '#cbd5e1', display: 'flex', alignItems: 'center', gap: 6 }}>
                                      {item.link ? (
                                        <a href={item.link} target="_blank" rel="noopener noreferrer"
                                          style={{ color: '#6366f1', textDecoration: 'none' }}>
                                          {item.value} <ExternalLink size={11} style={{ display: 'inline' }} />
                                        </a>
                                      ) : item.value}
                                      {item.verified !== undefined && (
                                        item.verified
                                          ? <CheckCircle2 size={13} color="#22c55e" />
                                          : <XCircle size={13} color="#ef4444" />
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>

                              {/* Reason */}
                              {lead.reason && (
                                <div style={{ background: '#0f1117', borderRadius: 10, padding: '12px 14px', marginBottom: 12 }}>
                                  <div style={{ fontSize: 11, color: '#64748b', fontWeight: 600, marginBottom: 4 }}>ANÁLISE</div>
                                  <div style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.6 }}>{lead.reason}</div>
                                </div>
                              )}

                              {/* WhatsApp button */}
                              {hasValidWhatsapp && (
                                <div style={{ marginBottom: 12 }}>
                                  <a href={getWhatsAppLink(lead.whatsapp!, lead.company)} target="_blank" rel="noopener noreferrer"
                                    style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '10px 18px',
                                      borderRadius: 10, background: '#14532d', color: '#4ade80',
                                      textDecoration: 'none', fontWeight: 600, fontSize: 14 }}>
                                    <MessageCircle size={16} /> Abrir WhatsApp
                                  </a>
                                </div>
                              )}

                              {/* Contact tracking */}
                              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                                {!lead.contactedAt ? (
                                  <button onClick={() => updateLead(lead.id, { contactedAt: new Date().toISOString() })}
                                    style={{ padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer',
                                      background: '#172554', color: '#60a5fa', fontWeight: 600, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <UserCheck size={14} /> Marcar Contactado
                                  </button>
                                ) : (
                                  <>
                                    <button onClick={() => updateLead(lead.id, { responseStatus: 'RESPONDED', respondedAt: new Date().toISOString() })}
                                      style={{ padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer',
                                        background: '#14532d', color: '#4ade80', fontWeight: 600, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                                      <CheckCircle2 size={14} /> Respondeu
                                    </button>
                                    <button onClick={() => updateLead(lead.id, { responseStatus: 'NO_RESPONSE' })}
                                      style={{ padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer',
                                        background: '#450a0a', color: '#fca5a5', fontWeight: 600, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                                      <UserX size={14} /> Sem Retorno
                                    </button>
                                  </>
                                )}
                                <button onClick={() => deleteLead(lead.id)}
                                  style={{ padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer',
                                    background: '#1a1d2e', color: '#6b7280', fontWeight: 600, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6,
                                    marginLeft: 'auto' }}>
                                  <Trash2 size={14} /> Remover
                                </button>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Stats Tab */}
        {activeTab === 'stats' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16 }}>
            {[
              { label: 'Total de Leads', value: stats.total, icon: Users, color: '#6366f1' },
              { label: 'Quentes', value: stats.quente, icon: Flame, color: '#ef4444' },
              { label: 'Mornos', value: stats.morno, icon: Thermometer, color: '#f97316' },
              { label: 'Contactados', value: stats.contacted, icon: UserCheck, color: '#22c55e' },
              { label: 'Responderam', value: stats.responded, icon: CheckCircle2, color: '#a855f7' },
              { label: 'Buscas', value: sessions.length, icon: Search, color: '#3b82f6' },
            ].map(item => {
              const Icon = item.icon;
              return (
                <div key={item.label} style={{ background: '#1a1d2e', borderRadius: 14, padding: 24, border: '1px solid #2d3149' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: '#0f1117',
                      display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Icon size={20} color={item.color} />
                    </div>
                    <span style={{ fontSize: 13, color: '#64748b', fontWeight: 600 }}>{item.label}</span>
                  </div>
                  <div style={{ fontSize: 36, fontWeight: 800, color: item.color }}>{item.value}</div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
